const {src, dest, task, series, watch, parallel} = require('gulp'),
    gulpSass = require('gulp-sass'),
    clean = require('gulp-clean'),
    browserSync = require ('browser-sync').create(),
    terser = require('gulp-terser'),
    concat = require ('gulp-concat'),
    imagemin = require('gulp-imagemin'),
    autoprefixer = require('gulp-autoprefixer'),
    fs = require('fs'),
    logger = new Logger();

let prepareFiles = parallel(convertImages('./src/images', './dist/images'), styles, javaScript);


task('build' , prepareFiles);
task ('dev', series(prepareFiles, function (cb) {
    browserSync.init({
        server: {
            baseDir: "./dist/"
        }
    });
    fs.watch('./src/images', {recursive: true}, series(convertImages('./src/images', './dist/images'), browserSync.reload));
    watch('./src/scripts').on('change', series(javaScript, browserSync.reload));
    watch('./src/sass').on('change', series(styles, browserSync.reload));
    watch('./dist/index.html').on('change', browserSync.reload);

cb();
}));
function convertImages(source, destination) {
    return (cb)=>{
        Promise.all([createPathsList(source), createPathsList(destination)])
            .then(([linksListSource, linksListDestination])=>Promise.all([
                linksListSource.getDifference(linksListDestination),
                linksListDestination.getDifference(linksListSource)]))
            .then(([copy, del])=>{
                let promisesList = [];
                logger.log(del);
                logger.log(copy);
                if (del.length)
                    del.forEach((path)=>{promisesList.push(cleanPath(path.replace(/\/$/, '')))});
                if (copy.length)
                    copy.forEach((img)=>{
                        let destPath = img.replace(copy.constatntPathPart, destination).replace(/.[^\/]+?$/, '');
                        promisesList.push(copyImage(img, destPath))
                    });
                return Promise.all(promisesList);
            })
            .then(()=>{if (typeof cb == 'function') cb()});
    }
}

function getDifference(fromList) {
    let difference = [];
    difference.constatntPathPart = this.constatntPathPart;
    return this.length?new Promise((resolve)=>{
        for (let index = 0; index<this.length; ++index){
            if (!~fromList.indexOf(this[index])) difference.push(this.getFileName(index));
            if (index+1 == this.length) resolve(difference);
        }
    }):Promise.resolve(difference);
}
function getFileName(index) {
    return this.constatntPathPart+this[index];
}
function createPathsList(dirPath) {
    let linksList = [];
    linksList.constatntPathPart = dirPath;
    linksList.getFileName = getFileName;
    linksList.getDifference = getDifference;
    let checkingDirsList = [];
    checkingDirsList.removeDir = function (dir) {
        this.splice(this.indexOf(dir), 1);
    };
    return new Promise((completeList)=>{
        readDir(dirPath);
        function readDir(path) {
            checkingDirsList.push(path);
            fs.readdir(path, (err, files)=>{
                if (err) logger.log(err);
                if (!files.length){
                    checkingDirsList.removeDir(path);
                    if (!checkingDirsList.length) completeList(linksList);
                }
                files.forEach((file, index)=>{
                    let currentPath = path+"/"+file;
                    fs.stat(currentPath, (err, stats)=>{
                        if (stats.isDirectory())
                            readDir(currentPath);
                        else {
                            linksList.push(currentPath.replace(dirPath, ''));
                        }
                        if (index+1 == files.length){
                            checkingDirsList.removeDir(path);
                            if (!checkingDirsList.length) completeList(linksList);
                        }
                    });

                });
            });
        }
    });

}


function javaScript (cb) {
    Promise.all([
        convertJS('./src/scripts/**/*.js'),
        cleanPath('./dist/scripts/**/*.js')
    ]).then(([convertedSream])=>{
        convertedSream.pipe(dest('./dist/scripts/'));
        convertedSream.on('end', cb);
    });
}
function styles (cb) {
    Promise.all([
        convertScss('./src/sass/!!_entryPoint.scss'),
        cleanPath('./dist/styles/**/*.css')
    ]).then(([convertedSream])=>{
        convertedSream.pipe(dest('./dist/styles/'));
        convertedSream.on('end', cb);
    });
}
function copyImage(source, destination) {
    return new Promise((resolve)=>{
        src(source)
            .pipe(imagemin())
            .pipe(dest(destination))
            .on('end', ()=>{
                logger.log(`Finished to copy from ${source} to ${destination}`);
                resolve();
            });
    });
}


function convertJS(path) {
    return new Promise((resolve)=>{
        let stream = src(path)
            .pipe(concat('scripts-min.js'))
            .pipe(terser());
        stream.on('prefinish', ()=>{
            logger.log('Prefinish converting JS');
            resolve(stream);
        });
    });
}
function convertScss(path) {
    return new Promise((resolve)=>{
        let stream = src(path)
            .pipe(gulpSass())
            .pipe(autoprefixer({
                browsers: ['last 16 versions'],
                cascade: false
            }))
            .pipe(concat('styles-min.css'));

        stream.on('prefinish', ()=>{
            logger.log('Prefinish converting Scss');
            resolve(stream);
        });
    });
}
function cleanPath(path) {
    return new Promise((resolve)=>{
        let stream = src(path).pipe(clean());
        stream.on('finish', ()=>{
            logger.log(`Cleaned ${path}`);
            resolve();
        });
    });
}

function Logger() {
    let startTime = Date.now();
    this.log = (msg)=>{
        if (typeof msg == "object") {
            console.log(`${Date.now() - startTime}ms.:`);
            console.dir(msg);
        } else console.log(`${Date.now() - startTime}ms.: ${msg}`);
    };
}